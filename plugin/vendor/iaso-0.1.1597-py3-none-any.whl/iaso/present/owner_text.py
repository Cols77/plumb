"""Every SP6 owner-visible string, in one place: the R14 choke point (sp6 11.1).

No text SP6 shows the owner names a bare ``iaso <verb>`` or any other shell command: it
names a ``/iaso`` command or the plain words to say. Lanes import these constants and
format functions and never inline owner wording; ``bare_cli_verbs`` is the test every
surface's output passes. Each lane's constants sit under its own heading.
"""

from __future__ import annotations

import re
from collections.abc import Mapping

# -- LOGS (sp6 6)
# 6.5, 10: the warning in iaso validate and in the merge report while legacy lines remain
LEGACY_LOG = ("iaso: {n} log entries are still in the old format (say \"migrate the logs\", "
              "or /iaso migrate the logs)")

# -- IDS (sp6 4, 5, 10)
ID_UNRESERVED = ("iaso: {ids} is not reserved (no git repository); /iaso merge-fix fixes "
                 "a collision later")
ID_BUSY = ("iaso: could not reserve an ID (another session is creating records); try again "
           "in a moment")
RENUMBERED = ("iaso: {old} \"{title}\" from the merged branch is now {new} ({references} "
              "references in {files} files; {approval}; {commits} commits' trailers mapped)")
APPROVAL_CARRIED = "the owner's approval carried"
APPROVAL_NONE = "no approval to carry"
COLLISION = ("  {id}: \"{ours}\" and \"{theirs}\" hold one ID ({where}); /iaso merge-fix "
             "fixes it")
COLLISIONS_HEADER = "ID collisions hold the merge (two records with one ID):"
NOTHING_TO_FIX = "iaso: no ID collision; nothing to fix"
WOULD_RENUMBER = "iaso: {old} \"{title}\" from the merged branch would become {new}"
FIX_REMAINS = ("iaso: {id} still has two records ({where}); say \"keep mine\" or \"keep "
               "theirs\" for it, then /iaso merge-fix")
FIX_BLOCKED = ("iaso: {id} \"{title}\" is not renumbered yet: {files} files that name it "
               "still hold merge conflicts; resolve them, then /iaso merge-fix")
PREVIEW = ("iaso: merging {ref} would bring {id} \"{theirs}\" while this branch holds {id} "
           "\"{ours}\"; /iaso merge-fix renumbers it after the merge")
# R17: an "ok" carried across a renumber is labelled wherever the confirmation is shown
CARRIED = "carried by renumber {old} -> {new}"
CARRIED_GLANCE = ("  carried by renumber {old} -> {new} \"{title}\": the owner's earlier ok of "
                  "these exact words (say \"revoke {new}\" if you did not mean it)")


def carried(old: str, new: str) -> str:
    return CARRIED.format(old=old, new=new)

# -- MERGEDRIVER: the driver's stderr, which git shows during the merge (7.4 to 7.6)
MERGED_FIELDS = "iaso: {record} \"{title}\" merged field by field ({what})"
CONFLICT_WRITTEN = ("iaso: {record} \"{title}\" was changed differently on {ours} and "
                    "{theirs}; it waits for your choice (/iaso conflicts)")
ADD_ADD = ("iaso: {record} was created on both sides as different records; /iaso merge-fix "
           "renumbers the incoming one")
UNPARSABLE = ("iaso: the record file of {record} \"{title}\" holds both versions of a text "
              "merge; say \"keep mine\" or \"keep theirs\" for it")
STILL_OPEN = ("iaso: {record} \"{title}\" still waits for your choice on an earlier conflict "
              "and was changed again on {ours} and {theirs}; git keeps both versions of it: "
              "say \"keep mine\" or \"keep theirs\" for it")
NO_DRIVER = ("iaso: the record file of {record} \"{title}\" was merged as plain text; "
             "/iaso init installs the record merge")

# -- the hooks status line of the driver (7.1)
DRIVER_STATUS = "merge driver: {state}"
DRIVER_MISSING = " (/iaso init installs it)"
DRIVER_INSTALLED = "installed"
DRIVER_NOT_INSTALLED = "not installed"
DRIVER_HALF = "attribute without driver"

# -- the merge report's unmerged section (8.5, 7.6, 10)
UNMERGED_HEADER = "record files git left unmerged hold the merge:"
MODIFY_DELETE = ("  {record} \"{title}\" was changed on {changed} and removed on {removed}; "
                 "say \"keep the changed one\" or \"keep it removed\"")

# -- the conflict card (8.3), wherever it appears
# SR-267: the agent's view keeps the IC- handle (SR-151); no record id, and the owner gets one
# question through the tool, without ids
CARD_HEAD = "▸ Conflict {ic} on \"{title}\"   (awaits the owner's choice)"
CARD_FIELD = "  {name}:"
CARD_MERGED = "  Merged on their own: {what}"
CARD_JUDGED = "  Compatible? JEV: {verdict} ({probability:.2f}){reason}"
CARD_NO_JUDGMENT = "  Compatible? no judgment available"
CARD_UNAVAILABLE = "  Compatible? judging unavailable: {cause}"
CARD_SAY = ("  Ask the owner with the question tool ({ours}'s, {theirs}'s, or combined); "
            "never in prose")
CARD_SAY_COMBINED = ("  Ask the owner with the question tool ({ours}'s, {theirs}'s, or the "
                     "combined one); never in prose")
CONFLICTS_HEADER = "intent conflicts wait for your choice (/iaso conflicts):"
NO_CONFLICTS = "iaso: no intent conflict waits for you"
CONFLICTS_BRIEF = "iaso: {n} intent conflict(s) await your choice (/iaso conflicts)"
CONFLICTS_CARD = "{n} conflict awaits you"
CONFLICTS_CARD_MANY = "{n} conflicts await you"

# -- choosing a side (8.4)
CHOOSE_REFUSED = ("iaso: only the owner chooses a side; say which version to keep (for "
                  "example \"keep {theirs}'s\")")
CHOSEN = "iaso: {record} \"{title}\" now holds {side} version"
CHOSEN_RECONFIRMED = " (your earlier ok of that version holds again)"
CHOSEN_PROPOSED = " (it waits for your ok, like any new wording)"
PROPOSED = ("iaso: a combined version of {record} \"{title}\" is put in the conflict's question; "
            "nothing changes until you choose")

SUGGESTED = ("iaso: your suggestion on {record} \"{title}\" is put in the conflict's question; "
             "nothing changes until the owner chooses")

# -- the merge-time check and its hook (10, R17)
MERGE_HELD = ("iaso: the merge is not recorded yet; once this is settled, say \"finish the "
              "merge\"")
FOREIGN_HOOK = ("iaso: your own pre-merge-commit hook was kept; say \"call iaso from my merge "
                "hook\" to add it")
PREMERGE_INSTALLED = ("iaso: merges are checked before git records them (a quick check, no "
                      "test run; the full test run happens when you push)")
PREPUSH_INSTALLED = ("iaso: pushes run the full test run once before git sends them (the "
                     "one full run; merges stay quick)")
FOREIGN_PREPUSH_HOOK = ("iaso: your own pre-push hook was kept; say \"call iaso from my push "
                        "hook\" to add the full test run to it")
COMMIT_HOLD_INSTALLED = ("iaso: merges finished by hand, rebases and cherry-picks get the same "
                         "quick check before git records them")
PREMERGE_REMOVED = "iaso: merges are no longer checked before git records them"
PREMERGE_UNCONFIRMED = "  \"{title}\" waits on a judge"   # no command, no id (SR-267)
# SR-260 (DEC-252): listed, never held on
PREMERGE_WAITING_HEADER = ("{n} requirement{s} this merge touches wait{v} on a judge (listed; "
                           "this does not hold the merge):")
PREMERGE_UNDECLARED_HEADER = ("files changed without a requirement that declares them (listed; "
                              "this does not hold the merge):")
# SR-260 (DEC-252, DEC-256, DEC-257): what holds a merge besides conflicts and integrity
PREMERGE_QUESTIONS_HEADER = "questions wait for you{held}:"
PREMERGE_HELD = "they hold the merge"   # DEC-271: only a merge into the default branch
PREMERGE_QUESTION = ("  a question waits for you on \"{title}\"; the agent asks it with the "
                     "question tool (the merge check's JSON report carries it)")
PREMERGE_FAILING_HEADER = ("acceptance tests this merge can affect have no passing run on the "
                           "current code ({held}the agent runs them):")
PREMERGE_VERIFY_UNAVAILABLE = ("  the test evidence could not be read ({error}); it holds the "
                               "merge: green needs test evidence")
PREMERGE_FULL_PENDING = ("  the full test suite is pending ({reasons}); it holds the merge until "
                         "a full run passes or you waive it for this change")
PREMERGE_REGRESSION = "  {test} passed before and now fails (it holds the merge)"
PREMERGE_CLAIMS_UNREADABLE_HEADER = ("the claims check could not read everything (listed; this "
                                     "does not hold the merge):")
PREMERGE_FAILING = "  \"{title}\": {test} ({state})"
PREMERGE_PROOFS_HEADER = ("what this merge delivers into {into} is not proven yet (it holds the "
                          "merge):")
PREMERGE_PROOFS_PREVIEW_HEADER = ("what this branch will deliver into {into} is not proven yet "
                                  "(it will hold the landing, not this check):")
PREMERGE_PROOF_NOT_SHOWN = ("  \"{title}\": its proof is not shown working yet; the agent shows "
                            "it, then asks you whether you saw it working")
PREMERGE_PROOF_NOT_CONFIRMED = ("  \"{title}\": you have not said you saw it working; the agent "
                                "asks you with the question tool")
PREMERGE_UNDECLARED = ("  {path} changed without a requirement that declares it; ask the agent "
                       "to link it to the requirement it serves")
PREMERGE_STALE_HEADER = ("links this merge leaves stale (repin each once its tests pass; a repin "
                         "that is refused goes to the owner as the judge's question):")
PREMERGE_VALIDATE_HEADER = ("validate errors in the records (fix each record, or relink a link "
                            "that is broken, then commit):")
PREMERGE_UNTESTED_HEADER = "links this merge adds to files no test covers:"
PREMERGE_CONTRADICTIONS_HEADER = "requirements that contradict each other:"
PREMERGE_CONTRADICTIONS_NOTE = ("requirements that may contradict each other (the judge was not "
                                "sure, so this does not hold the merge):")
PREMERGE_NOT_JUDGED = "iaso: could not judge whether the new requirements contradict live ones"
PREMERGE_COLLISION = ("  {record}: two different records hold this ID; /iaso merge-fix fixes "
                      "it")
PREMERGE_OK = "iaso: merge check: nothing holds this merge"
FOREIGN_COMMIT_HOOK = ("iaso: your own prepare-commit-msg hook was kept; say \"call iaso from "
                       "my commit hook\" to add the check of merges finished by hand, rebases "
                       "and cherry-picks")
PREMERGE_UNSTAGED_HEADER = "iaso's files changed but are not part of what git will record:"
PREMERGE_UNSTAGED = "  {path} is left out; say \"{finish}\" to include it"
PREMERGE_UNREADABLE_HEADER = "records iaso cannot read, so it cannot check them:"
STEP_HELD = ("iaso: this {operation} step is not recorded yet; once this is settled, say "
             "\"continue the {operation}\"")
STEP_OK = "iaso: {operation} check: nothing holds this step"
# R17 at a fast-forward (no merge commit, so git runs no pre-merge-commit hook): the
# post-merge hook checks what came in and puts the default branch back when it holds
FF_HEADER = ("iaso: quick merge check (no test run): {merging} into {into} (git moved {into} "
             "straight to it, without a merge commit)")
FF_UNDONE = ("iaso: so {into} was put back where it was and nothing is recorded yet; say "
             "\"merge {merging}\" to bring it in as a merge that waits until this is settled")
FF_NOT_UNDONE = ("iaso: {into} could not be put back ({why}); say \"undo the merge of "
                 "{merging}\" before anything else")
FOREIGN_POST_HOOK = ("iaso: your own post-merge hook was kept; say \"call iaso from my "
                     "post-merge hook\" so a fast-forward of the main branch is checked too")
FOREIGN_LAND_HOOK = ("iaso: your own post-commit hook was kept; say \"call iaso from my "
                     "post-commit hook\" so a merge you finish by hand starts the landing job")
LAND_HOOK_INSTALLED = "iaso: a merge you finish by hand into the main branch starts the landing job"
POST_HOOK_INSTALLED = ("iaso: a fast-forward of the main branch gets the same quick check "
                       "(it is put back when the check holds)")
FF_HOLD_SET = ("iaso: merges into {branch} always record a merge commit, so the quick check "
               "sees every one")
FF_HOLD_REMOVED = "iaso: merges into {branch} may fast-forward again"

# -- the plugin (SP7 4, SR-082 to SR-084)
INIT_DONE = ("iaso now follows this repository. It will show what you asked for, keep the work "
             "tied to it and check merges and pushes.")
COMMIT_MSG_INSTALLED = ("iaso: each commit is checked for the requirement it says it serves")
FOREIGN_COMMIT_MSG_HOOK = ("iaso: your own commit-msg hook was kept; say \"call iaso from my "
                           "commit-msg hook\" to add the check of the requirement each commit "
                           "serves")
NOT_ADOPTED = "/iaso:iaso init to adopt this repository"
GETTING_READY = ("iaso is getting ready for its first run; it will follow this session from "
                 "your next message")
NEEDS_PYTHON = ("iaso needs Python 3.12 on this machine; say 'install what iaso needs' and I "
                "will set it up")
OLD_INSTALL = ("iaso is set up here the old way; say 'move iaso to the plugin' to switch")
IGNORED = ("iaso will stay out of this repository; say 'use iaso here again' to bring it back")
UNIGNORED = "iaso will offer to follow this repository again"
MIGRATE_DONE = ("iaso now runs from the plugin here: its old settings and copies are gone, and "
                "git's checks call iaso's launcher.")
MIGRATE_KEPT = "  kept, because you changed it: {what}"
MIGRATE_KEPT_SETTINGS = "  kept, because they are yours: your own Claude Code settings"
MIGRATE_NOTHING = "iaso was not set up here the old way; nothing to move."


def conflicts_card(n: int) -> str:
    """The status card's part for open intent conflicts ("1 conflict awaits you")."""
    return (CONFLICTS_CARD if n == 1 else CONFLICTS_CARD_MANY).format(n=n)

# -- AWARENESS (sp6 9.4, SR-078): one line per record another worktree or branch changes
OVERLAP = 'iaso: {id} "{title}" is also being changed on branch {branch}'
OVERLAP_WORKTREE = " (worktree {worktree})"
OVERLAP_CLAIMED = ' (intent in flight there: "{summary}")'
MORE_OVERLAPS = "iaso: +{n} more also being changed elsewhere (/iaso status)"
OVERLAP_CARD = "{n} also changed on {labels}"
OVERLAP_CARD_ASCII = "overlap {n} ({labels})"
# R17: a change that already landed on the default branch after this branch started from
# it (its claim cleared there, but this branch still holds the words it replaced)
OVERLAP_SINCE_FORK = ('iaso: {id} "{title}" was changed on {branch} after this branch '
                      "started from it; build on {branch}'s words, or ask the owner which "
                      "holds before changing it here")
SINCE_FORK_SUMMARY = "changed there after this branch started"
CONFLICTS_CARD_PLURAL = CONFLICTS_CARD_MANY
STATUS_OVERLAPS_HEADER = "also being changed elsewhere (ask \"is anyone else changing X?\"):"
STATUS_NO_OVERLAPS = "also being changed elsewhere: nothing"

# -- intent in flight (ruling R17, SR-080, SR-081): the early intent-conflict card
EARLY_CARD_HEAD = "▸ Conflict on \"{title}\"   (awaits the owner's choice, before any work)"
EARLY_CARD_SIDE = "  {label:<10}  {text}"
EARLY_CARD_JUDGED = "  Compatible? {judgment}"
EARLY_CARD_SAME = "the same requirement is being changed on both branches"
EARLY_CARD_SAY = ("  Ask the owner with the question tool ({branch}'s, this one, or both); "
                  "never in prose")
# the same card shown on a branch that is neither side (the default branch after one side
# merged): both versions are labelled by branch, and only a branch's name answers it
EARLY_CARD_SAY_NAMED = ("  Ask the owner with the question tool ({a}'s, {b}'s, or both); "
                        "never in prose")
EARLY_QUESTION = 'Branch {branch} says "{theirs}"; this request says "{ours}": which one, or both?'
EARLY_THEIRS = "{branch}'s version"          # every option names its branch: the answer
# words that name "this side" only from the raising branch's point of view: shown on another
# branch, they become "<raising branch>'s version"
EARLY_RELATIVE = ("this request's version", "this request", "this work's version", "this work",
                  "this one", "keep this one", "this version", "ours", "mine")
EARLY_BOTH = "both, combined"
EARLY_KNOWN = ('iaso: {id} "{title}": the owner is asked on branch {branch} whether this work '
               "or that branch's holds; build on the answer")
EARLY_SETTLED = ('iaso: {id} "{title}": the owner settled it on branch {branch}: "{chosen}"; '
                 "build on that")
EARLY_COMPATIBLE = ('iaso: {id} "{title}" shares its feature with intent in flight on branch '
                    '{branch} ("{summary}"); judged compatible, nothing to ask')
# R12/R17: only a confident JEV verdict may say "compatible"; a word check or an unsure
# verdict names both versions and leaves the call to the agent's reading
EARLY_UNJUDGED = ('iaso: {id} "{title}" shares its feature with intent in flight on branch '
                  '{branch}; whether they agree could not be judged ({who}): {branch} says '
                  '"{theirs}"; this says "{ours}". If they differ, show the owner both and ask '
                  "which holds, or both")
# the owner's answer to an early conflict card, once recorded (answer.record_answer)
EARLY_ANSWERED = ('iaso: {id} "{title}": your answer is recorded: {chosen}; every branch '
                  "working on it builds on that")
# a merge-time conflict the owner already answered before work began (answer.apply_settled)
# R17, the losing lane: this checkout's record still holds the version the owner turned down
EARLY_SUPERSEDED = ('iaso: {id} "{title}" here still says "{ours}", but the owner chose '
                    '{chosen}: "{theirs}"; change it to match that answer before building on it')
EARLY_APPLIED = ('iaso: {id} "{title}" now holds {chosen}, as you answered before work '
                 'began; nothing to ask again (say "finish the merge" to record it)')
CARD_SETTLED = ("  Already answered by you before work began: {chosen} ({side}'s side); "
                "nothing to choose again")
# the state of an early-conflict decision's card (a DEC that asks which version holds)
EARLY_DEC_STATE = "awaits your choice — {say}"
EARLY_DRY_RUN = "iaso: nothing recorded (a preview)"
INFLIGHT_BUSY = ("iaso: could not record this work's intent for the other branches (another "
                 "session is recording at the same moment); it is retried at the end of the "
                 "turn")
INFLIGHT_NONE = "intent in flight on other branches: none"
INFLIGHT_HEADER = "intent in flight on other branches:"
INFLIGHT_LINE = '  {branch}: "{summary}" ({records})'


# --------------------------------------------------------------------------- SP8 UNDERSTAND
# First wordings (JUDGE finishes them): the stale card, the steps of the worker and the
# gate's two choices.
STEP_READING = "reading your answer"
STEP_CHECKING = "checking your request"
STEP_JUDGING = "judging {n} records"
STEP_JUDGING_BACKLOG = "judging the backlog"
# SR-336: a question a study proposed ahead of it serves
STUDY_FIRST = "Study it first"
STUDY_FIRST_NOTE = ("The band's study line opens the study in the room; the question waits "
                    "until you have read it.")
GATE_CLOSED = "Waiting for your answer before building: {reason}"
NOT_AVAILABLE = "not available in this build"
CONFIRM_YOU_SAID = "you said: {evidence}"
JUDGE_APPROVED = "approved on your behalf by the judge"   # SR-251: "N approved on ..."
AWAITS_QUESTIONS = ("awaits you: {n} question{s} about what you asked ({said}); the agent asks "
                    "them with the question tool")
AWAITS_JUDGE = "waiting on a judge: {n} record{s}"
AWAITS_NOTHING = "awaits you: nothing"
TYPED_CONFIRMED = "Confirmed: {titles}"
TYPED_SETTLE_GONE = "That switch no longer exists; nothing changed. Records are confirmed by you, or by the judge reading your words when automatic confirmation is on."
AUTO_APPROVE_SWITCHED = "Automatic confirmation is now {state}."
AUTO_APPROVE_NOT_YET = "Automatic confirmation is switched on, but not in effect yet: {reason}."
BACKLOG_DONE = "{judged} records judged, {questions} questions waiting for you"

# -- JUDGE: the cards, the trial and the summary
BEYOND_KEEP = "Keep it: this is what I meant"
BEYOND_DROP = "Drop it"
BEYOND_REWORD = "Reword it (say how)"
BACKLOG_STARTED = ("Judging the backlog: {records} records are queued in {jobs} groups; the status "
                   "line shows how far it is.")
BACKLOG_NOTHING = "Nothing in the backlog is left to judge."
EXAMPLE_N = "example {n}"


_IASO_VERB = re.compile(r"(?<![\w/.:-])iaso[ \t]+([a-z][a-z-]*)(?![\w-]*:)")


def bare_cli_verbs(text: str) -> list[str]:
    """Every ``iaso <verb>`` in ``text`` whose verb is a CLI route, not preceded by ``/``
    and not directly followed by ``:`` (so ``/iaso merge-fix`` and the label "iaso log:
    not available" pass, while ``iaso merge-fix`` and ``uv run iaso log migrate`` do
    not)."""
    from iaso.cli import ROUTES

    out: list[str] = []
    for match in _IASO_VERB.finditer(text):
        verb = match.group(1)
        if verb in ROUTES or verb in _SP6_VERBS:
            out.append(f"iaso {verb}")
    return out


# the SP6 verbs, recognised even before their routes exist in this build
_SP6_VERBS = frozenset({"merge-fix", "ids", "log", "merge-driver", "conflict", "conflicts",
                        "inflight"})


# --------------------------------------------------------------------------- SP8 STALE
# The stale-link card (SR-111): what the owner reads when what they confirmed may have changed
# and the agent could not settle it alone. Titles, never record IDs; no commands.
STALE_ISSUE_CODE = ('{path} changed after you confirmed "{title}", and I could not settle '
                    "whether it still does what you asked")
STALE_ISSUE_RECORD = ('"{title}" rests on "{other}", which was reworded since, and I could '
                      "not settle whether the two still agree")
STALE_ISSUE_LOST_TEST = ('The test that proved example {example} of "{title}" is gone and nothing '
                         "replaces it, so nothing shows it still holds")
STALE_OPTION_KEEP = "Keep the wording as it is"
STALE_OPTION_REWORD = "Reword it to match the change"
STALE_OPTION_UNDO = "Undo the change"
# SR-116: what each default option does and leaves undone, and why the first is recommended
STALE_CONSEQUENCE_KEEP = ("Keeps the requirement as it reads and the change as made; leaves "
                          "unchecked whether the change still does what the requirement says")
STALE_CONSEQUENCE_REWORD = ("Rewrites the requirement to say what the code now does; keeps the "
                            "change and drops what the old wording promised")
STALE_CONSEQUENCE_UNDO = ("Puts the code back as it was when you confirmed the requirement; "
                          "keeps the wording and drops whatever the change was for")
STALE_WHY_KEEP = ("I could not tell whether the change matters to what you asked; keeping both "
                  "as they are changes nothing while you read the change shown with this question")
# to the agent (SR-198 EX-11): the link's question waits in the internal store (DEC-384)
STALE_HOLD_ENDED = ('iaso held the turn open {n} times for "{title}" and then let it go; its '
                    "question is filed: ask the owner with the question tool.")


# --------------------------------------------------------------------------- SP7 slice 3
# Cards only at the end of a turn (sp7-realign-sp8 C1, C7, C8; SR-012, SR-116): the kinds the
# stop hook drew its own way, and what every card shows so the owner can choose without asking
# back. Titles, never record IDs; no commands.

REGRESSION_ISSUE = "a test that passed before now fails: {what}"
REGRESSION_FIX = "Fix the code so it passes again"
REGRESSION_CHANGE = "The test is wrong now: change it (say how)"
REGRESSION_WAIT = "Leave it failing for now"
REGRESSION_EVIDENCE = "{test} passed in an earlier run and fails now{note}"
REGRESSION_TEST_CHANGED = " (the test itself was changed since it passed)"
REGRESSION_LAST_RUN = " (last run {run})"
REGRESSION_HIDDEN = ("{test} passed, then failed, and passes now only because the test itself "
                     "was changed")

# SR-030: a confirmed requirement whose acceptance test changed since the owner confirmed it
TEST_CHANGED_ISSUE = ("the test that checks it was changed since you confirmed it: {tests}; is "
                      "the new test right?")
TEST_CHANGED_SAYS = "What you confirmed: {text}"
TEST_CHANGED_EXAMPLES = "Cases the test checks: {text}"
TEST_CHANGED_RESTORE = "Put the test back as you confirmed it"
TEST_CHANGED_KEEP = "The new test is right: confirm it"
TEST_CHANGED_LATER = "Leave it for now"


CONFLICT_ISSUE = "{ours} and {theirs} changed it in different ways"
CONFLICT_SIDE = "{side} says: {text}"
CONFLICT_SUGGESTED = "Suggested: {said}. {why}"
EARLY_TYPED_CHOOSE = ('To answer, type: /iaso conflict choose "{title}" --take '
                      "<{branch} | {ours} | both>")
EARLY_ISSUE = '{branch} says "{theirs}"; {label} says "{ours}"'

# SR-216: why iaso withdrew a stale-link question; logged only, never an owner line (SR-373)
WITHDRAWN_LINK_CURRENT = "its link is current again"
WITHDRAWN_LINK_GONE = "its link no longer exists"
# SR-162: the tidy job's reasons, its step and the line when it could not run
STEP_TIDYING = "checking your open questions"
STEP_PUSHBACK = "checking a question the agent sent back"   # SR-362
STEP_QUESTIONS = "reading the agent's questions to you"   # SR-167
CARDS_SETTLED = "Settled from your decision: {items}"


def settled_counts(counts: Mapping[str, int]) -> str:
    """How many cards a decision withdrew, repinned or reworded, and how many it could not
    settle (they stay)."""
    said = [f"{counts[a]} {word}" for a, word in (("withdraw", "withdrawn"),
            ("repin", "repinned"), ("reword", "reworded")) if counts.get(a)]
    if counts.get("stays"):
        said.append(f"{counts['stays']} could not be settled and stay open")
    return ", ".join(said)
# --------------------------------------------------------------------------- SP7 PRESS
# What a button press on a card answers (sp7-realign-sp8 C3, C6; DEC-032, DEC-034). Titles,
# never record IDs; no commands.
BUTTON_ASK_CHANGE = "Ask for a change"
BUTTON_LEAVE_OPEN = "Leave open"
PRESS_PREFILL = "Change to '{topic}': "
PRESS_CONFIRMED = 'You pressed {label}: now confirmed: {titles}.'
PRESS_REJECTED = 'You pressed {label}: dropped: {titles}.'
# a trial No (a misreading, SR-124): iaso's reading is marked wrong; the record is not dropped
PRESS_MISREAD = ("You pressed {label}: iaso's reading of {titles} is marked wrong; the record "
                 "stays as it is.")
PRESS_LEFT_OPEN = ('Left open: "{topic}". It stops coming back at the end of each turn until '
                   "it changes; it stays listed under what awaits you.")
PRESS_CHANGE = 'Say what to change about "{topic}"; your next message is read against it.'
PRESS_ANSWERED = 'You pressed {label} on "{topic}".'
PRESS_CHANGED_SINCE = '"{title}" changed since it was shown; nothing was confirmed.'
PRESS_ALREADY = '"{topic}" was already answered; nothing changed.'
PRESS_MODEL_CONFIRMED = ("The owner pressed {label}; now confirmed: {records}. Do not ask "
                         "again.")
PRESS_MODEL_REJECTED = "The owner pressed {label}; dropped: {records}."
PRESS_MODEL_MISREAD = ("The owner pressed {label}; iaso's reading of {records} is marked wrong. "
                       "The record stays: do not remove or rewrite it.")
PRESS_MODEL_LEFT_OPEN = ('The owner pressed Leave open on "{topic}". Do not ask about it '
                         "again until it changes.")
PRESS_MODEL_CHANGE = ('The owner pressed Ask for a change on "{topic}"; their next message '
                      "says what to change.")
PRESS_MODEL_ANSWERED = 'The owner pressed {label} on "{topic}".'
PRESS_MODEL_CHANGED = ("The owner pressed {label}, but {records} changed since it was shown; "
                       "nothing was confirmed and the new version is asked again as a fresh question.")

# --------------------------------------------------------------------------- SP7 MOD
# What iaso's panel adds (SP7 5.1, 5.8; sp7-realign-sp8 C6, C7).
