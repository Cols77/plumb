"""``iaso question reword`` (SR-362, DEC-340): what the coding agent may do with the judge's
questions before the owner sees them.

``reword --covers KEY[,KEY...] --question Q --header H --options JSON`` records the agent's
wording of the judge questions it covers, in the owner's terms and merged on one principle
(``judge.reword``): the owner's answer to it answers each of them. A KEY is a judge question's
text as ``clarify --wait`` gives it, or a start of it naming one open question, or the
whole text of a hidden-regression flag's question as the merge check gives it
(``testchange.flag_questions``, one ``--covers`` each). Nothing here
drops, answers or defaults a question: one the owner already answered is the judge's to not
raise (``judge._questions``)."""

from __future__ import annotations

import argparse
import json
import sys
from collections.abc import Mapping, Sequence
from typing import Any

NO_MATCH = "iaso: {key!r} names no open question of the judge; nothing recorded."
REWORDED = "iaso: your wording covers {n} question(s); the owner's answer to it answers each."


def _resolve(keys: Sequence[str], words: str) -> str | None:
    """The open question key ``words`` names: its text, or a start of it naming only one."""
    from iaso.understand.judge import question_key

    want = question_key(words)
    if want in keys:
        return want
    found = [k for k in keys if want and k.startswith(want)]
    return found[0] if len(found) == 1 else None


def _covered(keys: Sequence[str], given: Sequence[str]) -> list[str] | str:
    """The keys each ``--covers`` value names, whole or split on commas; else the value that
    names none."""
    from iaso.understand.testchange import flag_key

    out: list[str] = []
    for value in given:
        # report-5f6565d7: a hidden-regression flag's question (the merge check builds it, no
        # session files it) is covered by its whole text, one ``--covers`` each
        whole = _resolve(keys, value) or flag_key(value)
        parts = [whole] if whole else [_resolve(keys, p) for p in value.split(",")]
        if None in parts:
            return value
        out += [p for p in parts if p and p not in out]
    return out


def _options(raw: str) -> list[dict[str, Any]] | None:
    """The question tool's options: two to four ``{label, description}``."""
    try:
        data = json.loads(raw)
    except ValueError:
        return None
    if not isinstance(data, list) or not 2 <= len(data) <= 4 or not all(
            isinstance(o, Mapping) and str(o.get("label") or "").strip() for o in data):
        return None
    return [{"label": str(o["label"]), "description": str(o.get("description") or "")}
            for o in data]


def _reopen(core: Any, session: str, words: str) -> int:
    """SR-218, SR-217: the owner's word undoes a closure or settlement the tidy job made: the
    question waits again."""
    from iaso.understand import tidy

    closed = [str(k) for e in core.events() if e.kind == "answer-bound"
              and e.payload.get("by") == "tidy" for k in e.payload["asked"].get("keys") or ()]
    closed += [str(e.payload.get("key")) for e in core.events() if e.kind == "question-withdrawn"
               and e.payload.get("by") == "tidy"]
    key = _resolve(closed, words)
    if key is None:
        print(NO_MATCH.format(key=words), file=sys.stderr)
        return 1
    tidy.undo_settlement(core, key)
    core.log_append_many("events", [("answer-unbound", {"session": session, "key": key})])
    print("iaso: that question waits for the owner again.")
    return 0


def run(command: str, argv: list[str]) -> int:
    from iaso.api import open_core
    from iaso.cliutil import add_common, resolve_root
    from iaso.stale import current_session
    from iaso.understand import judge

    parser = argparse.ArgumentParser(prog="iaso question")
    add_common(parser)
    parser.add_argument("--session", default="")
    sub = parser.add_subparsers(dest="verb", required=True)
    reword = sub.add_parser("reword", help="your wording of the judge questions it covers")
    reword.add_argument("--covers", action="append", required=True)
    reword.add_argument("--question", required=True)
    reword.add_argument("--header", required=True)
    reword.add_argument("--options", required=True, help="JSON: [{label, description}, ...]")
    reopen = sub.add_parser("reopen", help="take back a closure of a waiting question")
    reopen.add_argument("words", help="the question's words, or the start of them")
    args = parser.parse_args(argv)
    root = resolve_root(args.root)
    core = open_core(root)
    session = args.session or current_session(root)
    if args.verb == "reopen":
        return _reopen(core, session, args.words)
    # any session's question: one filed by the CLI or an ended session is answerable here
    keys = [str(q.get("key")) for q in judge.open_questions(core, session)]
    keys += [k for k in (str(q.get("key")) for q in judge.unanswered_anywhere(core))
             if k not in keys]
    covers = _covered(keys, args.covers)
    options = _options(args.options)
    if isinstance(covers, str):
        print(NO_MATCH.format(key=covers), file=sys.stderr)
        return 1
    if options is None:
        print("iaso: --options is a JSON list of two to four {label, description}.",
              file=sys.stderr)
        return 2
    if judge._LEFT_IN.search(" ".join([args.question, args.header,
                                       *(o["label"] for o in options)])):
        print("iaso: put the question in the owner's terms, with no record id.",
              file=sys.stderr)        # SR-362 EX-1
        return 2
    judge.reword(core, session, covers, args.question, args.header, options)
    print(REWORDED.format(n=len(covers)))
    return 0
