"""The backlog pass (JUDGE, SR-107, spec 8).

The records proposed before SP8 are judged in **one background pass**: a series of judge jobs,
each covering the records of one intent as a capture does, queued together and never metered per
turn. A job already done is not run again unless its record changed (a job is its records at
their versions, so the same records are the same job), and a pass a failure interrupted resumes
on the next turn from where it stopped: ``start`` queues only the records that have no judgment
at their current version.

What the pass finds comes as trial cards when it ends (``trial.cards_for``, three open at most);
a flagged record (beyond, contradicts) is an issue card instead; a record whose premise is only
a fragment of the owner's words gets a trial card that says its words were not found.

While it runs the pass reports "judging the backlog" with the records judged and the total
(``progress.Reporter``); when it ends the last job writes the end line."""

from __future__ import annotations

import time
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from plumb.contracts import CardState
from plumb.present import owner_text
from plumb.understand import files

PASS = "backlog"
KINDS_JUDGED = ("intent", "requirement", "decision")


@dataclass
class Started:
    """What ``start`` queued: the job ids, the records they cover, the pass's total."""

    jobs: list[str] = field(default_factory=list)
    records: int = 0
    total: int = 0


@dataclass
class After:
    cards: list[CardState] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


# --------------------------------------------------------------------------- the records


def marker_path(root: Any, session: str) -> Any:
    return files.session_dir(root, session) / "backlog.json"


def proposed(core: Any) -> list[Any]:
    """The records waiting for the owner that the judge covers: proposed, or edited since the
    owner confirmed them, and not superseded."""
    index = core.index()
    statuses = core.status()
    return [index[i] for i in sorted(index)
            if index[i].kind in KINDS_JUDGED and statuses[i].confirmation != "confirmed"
            and statuses[i].superseded_by is None]


def latest_verdicts(core: Any) -> dict[str, Mapping[str, Any]]:
    out: dict[str, Mapping[str, Any]] = {}
    for entry in core.events():
        if entry.kind == "verdict":
            out[str(entry.payload.get("id"))] = entry.payload
    return out


def judged_ids(core: Any, records: Sequence[Any]) -> set[str]:
    """The records with a judgment of their current version."""
    verdicts = latest_verdicts(core)
    return {r.id for r in records if verdicts.get(r.id, {}).get("hash") == r.hash}


def group_of(index: Mapping[str, Any], record: Any) -> str:
    """The intent a record belongs to (itself for an intent or a record deriving from none)."""
    if record.kind == "intent":
        return record.id
    for link in record.links:
        if link.kind == "derives_from" and link.target.record in index \
                and index[link.target.record].kind == "intent":
            return link.target.record
    return record.id


# --------------------------------------------------------------------------- the pass


def start(core: Any, session: str) -> Started:
    """Queue the judge jobs of the pass: one per intent, covering the records that have no
    judgment of their current version. Idempotent: a job is its records, so jobs already
    queued or done are the same jobs. Marks the pass as started so ``resume`` continues it."""
    from plumb.understand import judge, queue

    records = proposed(core)
    done = judged_ids(core, records)
    index = core.index()
    groups: dict[str, list[str]] = {}
    for record in records:
        if record.id not in done:
            groups.setdefault(group_of(index, record), []).append(record.id)
    out = Started(records=sum(len(v) for v in groups.values()), total=len(records))
    for key in sorted(groups):
        job = judge.build(core, session, records=groups[key], **{"pass": PASS,
                                                                  "total": len(records)})
        if job is not None:
            queue.enqueue(core, job)
            out.jobs.append(job.id)
    files.write_json_atomic(marker_path(core.root, session), {
        "started": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "total": len(records)})
    return out


def resume(core: Any, session: str) -> Started:
    """Continue a pass that was started (a failed job is queued again by the queue); nothing
    when no pass was started or nothing is left."""
    if not marker_path(core.root, session).exists():
        return Started()
    return start(core, session)


def holding(core: Any, session: str) -> set[str]:
    """The records a started pass that is not finished keeps back from the trial: their
    cards come when the pass ends."""
    if not marker_path(core.root, session).exists():
        return set()
    records = proposed(core)
    if len(judged_ids(core, records)) >= len(records):
        return set()
    return {r.id for r in records}


# --------------------------------------------------------------------------- cards


def after_job(core: Any, job: Any, *, supported: Sequence[Any],
              verdicts: Sequence[Mapping[str, Any]], fragments: Sequence[Any],
              flagged: Sequence[CardState]) -> After:
    """Called by ``judge.apply`` for a job of the pass: report the progress; when this job
    finishes the pass, open the trial cards and write the end line. ``supported`` are the
    supported records of the last job and ``fragments`` the records whose original words are
    not on file (their trial card says so); neither is in the log yet."""
    from plumb.progress import Reporter
    from plumb.understand import trial

    records = proposed(core)
    judged = judged_ids(core, records) | {str(v["id"]) for v in verdicts}
    waiting_for = [r for r in records if r.id not in judged]
    total = max(int(job.inputs.get("total") or 0), len(records))
    done = total - len(waiting_for)
    reporter = Reporter(core.root, job.session, "judge")
    if waiting_for:
        reporter.update(owner_text.STEP_JUDGING_BACKLOG, done, total)
        return After()
    scores = {str(v["id"]): float(v.get("score") or 0) for v in verdicts}
    seen = {c.record.id for c in supported}
    extra = [*supported, *(trial.Candidate(r, scores.get(r.id, 0.0), {}) for r in fragments
                           if r.id not in seen)]
    built = trial.cards_for(core, job.session, extra, pass_done=True)
    reporter.done(final=owner_text.BACKLOG_DONE.format(judged=done,
                                                       cards=len(built) + len(flagged)))
    return After(cards=built)


def run(command: str, argv: list[str]) -> int:
    """``plumb understand backlog``: start (or continue) the pass from a shell."""
    import argparse

    from plumb.api import open_core
    from plumb.cliutil import add_common, resolve_root

    parser = argparse.ArgumentParser(prog="plumb understand backlog")
    add_common(parser)
    parser.add_argument("--session", default=files.CLI_SESSION)
    args = parser.parse_args(argv)
    core = open_core(resolve_root(args.root))
    started = start(core, args.session)
    print(owner_text.BACKLOG_STARTED.format(records=started.records, jobs=len(started.jobs))
          if started.jobs else owner_text.BACKLOG_NOTHING)
    return 0
