"""The debug workflow (SR-220, SR-221, SR-300), standalone: ``plumb debug [ID ...] [--dry-run]``.

The cases plumb could not settle on its own (today: stale and dangling links) are rerun once
through the step the turn end runs, ``links.repin_after_tests`` (tests, then the meaning
cascade). What each case did and what it still needs is reported as text; a record whose
meaning changed under a decision becomes one owner question through the question tool (SR-300
EX-3), never a card. The plumb line counts the cases in debugging and the ones resolved.
Nothing here confirms anything or changes a record's meaning.
"""

from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Any

LINE = "plumb: debug: {n} cases, {resolved} resolved, {open} still in debugging"
STORE = (".plumb", "cache", "debug")
DANGLING = "its target no longer exists, so there is nothing to repin to: relink it"
OWN_KINDS = frozenset({"landing-step", "validate"})   # DEC-316: plumb's own, at a landing
READY_REPIN = ("plumb: the repins of {branch} ({detail}) are committed, tests passed: ready to "
               "land; merge it like any branch, through the merge check")
READY = ("plumb: self-fix {branch} ({kind}: {detail}) is committed and reviewed: ready to "
         "land; merge it like any branch, through the merge check")
FIXED = "plumb: the plumb defect you hit is fixed in main ({kind}: {detail}); retry {retry}"
RETRY = {"hook-error": "what ran the {target} hook", "landing-step": "the landing's {target} step",
         "validate": "plumb validate", "report": "what you flagged", "job-failed": "the job"}


def _case_path(root: Path | str, case_id: str) -> Path:
    return Path(root).joinpath(*STORE, re.sub(r"[^\w.-]", "_", case_id) + ".json")


def _same(text: str) -> str:
    """One cause, one id: the digest ignores the numbers (a pid, a line number)."""
    return hashlib.sha1(re.sub(r"\d+", "", text).encode()).hexdigest()[:8]


def open_case(root: Path | str, *, id: str, kind: str, target: str, detail: str,
              log: str = "", session: str | None = None) -> None:
    """SR-325: one case file per id, written the moment a failure happens (idempotent; a
    failure to write it is swallowed, since it runs inside the failing step). It keeps the
    session that detected it (DEC-318), told there once its fix is in main (``lines``)."""
    try:
        path = _case_path(root, id)
        if path.exists():
            return
        from plumb import stale

        path.parent.mkdir(parents=True, exist_ok=True)
        row = {"id": id, "kind": kind, "target": target, "detail": detail, "state": "open",
               "log": log, "session": session or stale.current_session(root)}
        path.write_text(json.dumps(row, ensure_ascii=False, indent=1), encoding="utf-8")
        _queue_fix(root, id)
    except Exception:  # noqa: BLE001 - recording a case never fails the step that failed
        pass


def _queue_fix(root: Path | str, case_id: str) -> None:
    """SR-326: in plumb's own repository the case also becomes a background self-debug job."""
    from plumb import selfdebug, stale
    from plumb.api import open_core
    from plumb.understand import queue
    from plumb.understand import selfdebug as kind

    core = open_core(Path(root))
    if selfdebug.applies(core) is None:
        queue.enqueue(core, kind.build(core, stale.current_session(core.root), case=case_id))


def all_cases(root: Path | str) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for path in sorted(Path(root).joinpath(*STORE).glob("*.json")):
        try:
            row = json.loads(path.read_text("utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(row, dict) and row.get("id"):
            out.append(row)
    return out


def open_cases(root: Path | str) -> list[dict[str, Any]]:
    return [r for r in all_cases(root) if r.get("state") == "open"]


def _update(root: Path | str, ids: list[str], **fields: Any) -> int:
    changed = 0
    for case_id in ids:
        path = _case_path(root, case_id)
        try:
            row = json.loads(path.read_text("utf-8"))
        except (OSError, ValueError):
            continue
        if any(row.get(k) != v for k, v in fields.items()):
            path.write_text(json.dumps({**row, **fields}, ensure_ascii=False, indent=1),
                            encoding="utf-8")
            changed += 1
    return changed


def resolve(root: Path | str, ids: list[str]) -> int:
    """Mark cases resolved; returns how many changed."""
    return _update(root, ids, state="resolved")


def report(root: Path | str, id: str, text: str) -> None:
    _update(root, [id], report=text)


def hook_error(root: Path | None, name: str, detail: str) -> None:
    """SR-325 EX-1: a hook that raised leaves one case, the same error once. The id ignores
    the numbers in the traceback (a temp file's pid, line numbers), so one cause is one case
    and one background fix, not one per process that hit it."""
    if root is None:
        return
    lines = detail.strip().splitlines()
    open_case(root, id=f"hook-{name}-{_same(detail)}",
              kind="hook-error", target=name, detail=lines[-1] if lines else name, log=detail)


def from_landing(root: Path | str, found: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """DEC-316: where self-debug runs, plumb's own defects a landing found (a failed step, a
    validate error) open real cases, queued for the background fix like hook errors; the
    cases left (stale links, judge questions, tests) stay with the agent (SR-300)."""
    from plumb import selfdebug
    from plumb.api import open_core

    try:
        if selfdebug.applies(open_core(Path(root))) is not None:
            return found
    except Exception:  # noqa: BLE001 - the landing's cases are never lost
        return found
    for c in found:
        if c["kind"] in OWN_KINDS:
            open_case(root, id=f"{c['id']}-{_same(str(c['detail']))}", kind=c["kind"],
                      target=str(c["target"]), detail=str(c["detail"]))
    return [c for c in found if c["kind"] not in OWN_KINDS]


def landed(root: Path | str, head: str) -> None:
    """DEC-318: at a landing, a fixed case whose branch is now in main is marked landed."""
    for row in all_cases(root):
        if row.get("branch") and not row.get("landed") and subprocess.run(
                ["git", "merge-base", "--is-ancestor", str(row["branch"]), head], cwd=root,
                capture_output=True).returncode == 0:
            _update(root, [row["id"]], landed=head)


def lines(root: Path | str, session: str) -> list[tuple[str, str]]:
    """``(key, text)`` for the agent's next prompt: each committed, reviewed self-fix not yet
    in main is ready to land (DEC-317: plumb never merges it); a case this session detected
    whose fix is in main is fixed, with what to retry (DEC-318: nothing held it)."""
    out: list[tuple[str, str]] = []
    for row in all_cases(root):
        what = {k: str(row.get(k) or "") for k in ("branch", "kind", "detail", "target")}
        if row.get("branch") and not row.get("landed"):
            out.append((f"ready:{row['id']}",
                        (READY_REPIN if what["kind"] == "repin" else READY).format(**what)))
        elif row.get("landed") and row.get("session") == session:
            retry = RETRY.get(what["kind"], "what failed ({target})").format(**what)
            out.append((f"fixed:{row['id']}", FIXED.format(retry=retry, **what)))
    return out


def flag(root: Path | str, words: str) -> str:
    """DEC-319: what the owner or the agent noticed (a wrong result, not a crash) is a case,
    queued for the same background fix as a crash."""
    case_id = f"report-{_same(words)}"
    open_case(root, id=case_id, kind="report", target="flagged", detail=words)
    return case_id


def cases(core: Any, selectors: list[str], *, dry_run: bool = False,
          session: str | None = None, **test_doubles: Any) -> list[dict[str, str]]:
    """One ``{case, state, what}`` per stale or dangling link of ``selectors`` (record IDs or
    link ids; none: every record with one). ``state`` is ``resolved``, ``would resolve`` (dry
    run) or ``open``; ``what`` says what happened or what is missing."""
    from plumb import stale
    from plumb.links import LinkError, repin_after_tests

    states = [s for s in core.link_states() if s.state in ("stale", "dangling")]
    records = selectors or sorted({s.link.source for s in states})
    where = session or stale.current_session(core.root)
    out: list[dict[str, str]] = []
    for record in records:
        wanted = record.split("#")[0]
        out += [{"case": s.link.id, "state": "open", "what": DANGLING} for s in states
                if s.state == "dangling" and s.link.source == wanted
                and (record == wanted or s.link.id == record)]
        try:
            step = repin_after_tests(core, record, session=where, dry_run=dry_run,
                                     **test_doubles)
        except LinkError as exc:
            out.append({"case": record, "state": "open", "what": str(exc)})
            continue
        out += [{"case": c["link"], "state": "resolved",
                 "what": f"repinned ({c.get('tier', 'tests pass')})"} for c in step.changes]
        out += [{"case": link, "state": "would resolve", "what": why} for link, why in step.would]
        out += [{"case": link, "state": "open", "what": why} for link, why in step.refused]
    return out


def _store_cases(root: Path | str, found: list[dict[str, str]],
                 dry_run: bool) -> list[dict[str, str]]:
    """The store's cases beside the links: a refused link whose rerun resolved it (or that is
    no longer stale) is marked resolved; the other kinds have no step to rerun yet."""
    out: list[dict[str, str]] = []
    for row in all_cases(root):
        link, state = str(row["target"]), row.get("state")
        if state == "open" and row.get("kind") == "stale-refused":
            mine = [c for c in found if c["case"] == link]
            if all(c["state"] == "resolved" for c in mine) and not dry_run:
                resolve(root, [row["id"]])
                state = "resolved"
            if mine:
                continue  # listed with the links
        out.append({"case": row["id"], "state": "open" if state == "open" else "resolved",
                    "what": str(row.get("report") or row.get("detail") or row.get("kind"))})
    return out


def _elsewhere(core: Any, still_open: set[str]) -> None:
    """SR-327: outside plumb's own repository a case whose rerun failed again ends with a
    defect report (or, configured, a fix in the source checkout), once."""
    from plumb import selfdebug

    if selfdebug._own(Path(core.root)):
        return
    for row in open_cases(core.root):
        if row["id"] in still_open and not row.get("report"):
            if line := selfdebug.handle(core, row).line:
                print(line)


def _fix(core: Any, ids: list[str]) -> int:
    """``plumb debug fix [id]``: the self-debug workflow on demand (SR-326)."""
    from plumb import selfdebug

    if (why := selfdebug.applies(core)) is not None:
        print(f"plumb: debug fix: {why}")
        return 1
    todo = [c for c in open_cases(core.root) if not ids or c["id"] in ids]
    outcomes = [(c["id"], selfdebug.fix(core, c)) for c in todo]
    for case_id, out in outcomes:
        print(out.line or f"  {case_id}: {out.state}: {out.detail}")
    return 0 if outcomes and all(o.state == "fixed" for _, o in outcomes) else 1


def on_branch(core: Any, work: Any, *, dry_run: bool = False) -> tuple[Any, str]:
    """SR-351 (DEC-323): ``work(core)`` -> result, made in plumb's own repository in a worktree
    on ``debug/repin`` (built from main's committed head, so uncommitted or untracked work in
    main is not seen), the edits committed there with the SR trailer and announced as ready to
    land (``lines``); the checkout is left unchanged. The branch starts over from main's head
    each pass (the links are re-derived, so an unlanded earlier commit is replaced, and kept
    when this pass changes nothing). Elsewhere, ``work(core)`` runs in place. ``(result,
    error)``: error says why the commit failed (the edits are then dropped)."""
    from plumb import selfdebug
    from plumb.api import open_core

    root = Path(core.root)
    if dry_run or not (root / ".git").is_dir() or not selfdebug._own(root):
        return work(core), ""
    wt, branch = selfdebug._worktree(root, "repin")
    prev = selfdebug._git(wt, "rev-parse", "HEAD").strip()
    head = selfdebug._git(root, "rev-parse", "HEAD").strip()
    selfdebug._git(wt, "reset", "-q", "--hard", head)
    wt_core = open_core(wt)
    result = work(wt_core)
    try:
        selfdebug._git(wt, "add", "-u")
        changed = selfdebug._git(wt, "diff", "--cached", "--name-only").split()
        if not changed:
            selfdebug._git(wt, "reset", "-q", "--hard", prev)
            return result, ""
        names = sorted({Path(f).stem for f in changed})
        linked = {link.target.record for n in names if n in wt_core.index()
                  for link in wt_core.index()[n].links if link.target.record}
        srs = sorted({n for n in (*names, *linked) if n.startswith("SR-")})
        sr_line = f"SR: {', '.join(srs)}\n\n" if srs else ""
        text = (f"Repin the stale links of {', '.join(names)}\n\n{sr_line}"
                "Co-Authored-By: Claude Opus 5.5 <noreply@anthropic.com>\n")
        with tempfile.NamedTemporaryFile("w", suffix=".txt", delete=False,
                                         encoding="utf-8") as f:
            f.write(text)
        try:
            selfdebug._git(wt, "commit", "-q", "-F", f.name)
        finally:
            Path(f.name).unlink(missing_ok=True)
    except subprocess.CalledProcessError as exc:
        selfdebug._git(wt, "reset", "-q", "--hard", prev, check=False)
        return result, f"the repin commit failed: {str(exc.stderr or exc).strip()}"
    for row in all_cases(root):   # one announcement: an unlanded earlier pass is replaced
        if row.get("kind") == "repin" and not row.get("landed"):
            _case_path(root, row["id"]).unlink(missing_ok=True)
    sha = selfdebug._git(wt, "rev-parse", "--short", "HEAD").strip()
    path = _case_path(root, f"repin-{sha}")
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps({"id": f"repin-{sha}", "kind": "repin", "target": branch,
                                "detail": f"repinned {', '.join(names)}", "state": "resolved",
                                "branch": branch}, indent=1), encoding="utf-8")
    return result, ""


def _pass(core: Any, selectors: list[str], dry_run: bool) -> list[dict[str, str]]:
    found, error = on_branch(core, lambda c: cases(c, selectors, dry_run=dry_run),
                             dry_run=dry_run)
    if error:
        found = [{**c, "state": "open", "what": error} if c["state"] == "resolved" else c
                 for c in found]
    return found


def run(command: str, argv: list[str]) -> int:
    import argparse

    from plumb.api import open_core
    from plumb.cliutil import add_common, emit, resolve_root

    parser = argparse.ArgumentParser(
        prog=f"plumb {command}",
        description="Run the debug cases once (stale links through tests and the meaning "
                    "cascade) and say what each did and what it still needs. Never confirms.")
    add_common(parser)
    parser.add_argument("selector", nargs="*", help="record IDs or link ids; default: all")
    parser.add_argument("--dry-run", action="store_true",
                        help="ask the models only: no tests, no repin, no owner question")
    args = parser.parse_args(argv)
    core = open_core(resolve_root(args.root))
    if args.selector[:1] == ["done"]:
        print(f"plumb: debug: {resolve(core.root, args.selector[1:])} cases marked resolved")
        return 0
    if args.selector[:1] == ["fix"]:
        return _fix(core, args.selector[1:])
    if args.selector[:1] == ["report"]:
        words = " ".join(args.selector[1:]).strip()
        if not words:
            print("usage: plumb debug report <what is wrong, in words>", file=sys.stderr)
            return 2
        print(f"plumb: debug: case {flag(core.root, words)} opened; the fix runs in the "
              "background")
        return 0
    found = _pass(core, args.selector, args.dry_run)
    if not args.selector:
        found += _store_cases(core.root, found, args.dry_run)
        if not args.dry_run:
            _elsewhere(core, {c["case"] for c in found if c["state"] == "open"})
    resolved = sum(c["state"] != "open" for c in found)
    if args.as_json:
        emit({"cases": found, "resolved": resolved}, True)
    else:
        print(LINE.format(n=len(found), resolved=resolved, open=len(found) - resolved))
        for c in found:
            print(f"  {c['case']}: {c['state']}: {c['what']}")
    return 1 if resolved < len(found) else 0


if __name__ == "__main__":
    sys.exit(run("debug", sys.argv[1:]))
