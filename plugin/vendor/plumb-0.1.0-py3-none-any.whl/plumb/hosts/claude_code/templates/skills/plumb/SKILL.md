---
name: plumb
description: Ground work in this repository's plumb records (owner intent, requirements with examples, decisions, tests). Use when changing code or tests, when the owner states or changes intent, or when a "plumb:" hook line appears.
---
# plumb

Run plumb as `{plumb}`. Context lives in files; read it before acting.

- `.plumb/` holds INT (the owner's words), SR (requirements with given/when/then examples),
  DEC (decisions), FEAT and NC. `{plumb} brief` is the current intent; `{plumb} show <ID>`
  a record's examples and tests; `{plumb} explain <words>` why something exists.
- Before editing a file, grep `.plumb/test_map.txt` for it: the tests listed cover it. Never
  rewrite a confirmed example's acceptance test to make it pass. When the stop hook asks,
  run the command it names (`{plumb} tests run --changed`).
- When a request starts or changes intent, load the plumb-clarify skill
  (`{plumb} clarify "<request>"` gives the depth and the questions that matter).
- Read back each request in the owner's terms and record it in one call:
  `{plumb} capture --prompt <digest> --file <doc.json>` (verbatim quote, will, won't,
  labelled assumptions, examples with edge cases, implemented_by paths); put the intent card
  it prints in your reply. All proposed; it never blocks. Two readings fit:
  `{plumb} decide --question Q --chosen A --alt B [--matters]`.
- Ask the owner only on a contradiction or extension of a confirmed record, an unconfirmed
  decision that matters (one per message), or a regression.
- You never decide that the owner approved: only their typed `/plumb approve <IDs>` or plumb's
  own reader of their next message confirms; `{plumb} relay` is refused whatever the words
  (`{plumb} triage` lists the low-risk group). Silence confirms nothing.
- Never run `plumb approve`, `revoke`, `triage --approve`, `spec approve`,
  `config auto-approve` or `conflict choose`: they belong to the owner's own terminal.
  A merge conflict's side is relayed only from the owner's words (`/plumb conflicts`).
- Commits carry an `SR: SR-###` trailer naming the requirements they serve.
