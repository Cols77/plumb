import{ah as o,ai as n}from"./mermaid.core-C3O8WsDq.js";const t=(a,r)=>o.lang.round(n.parse(a)[r]);export{t as c};
